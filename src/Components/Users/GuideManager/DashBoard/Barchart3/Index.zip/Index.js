import React, { Component } from "react";
import ReactApexChart from "react-apexcharts";


export default class Index extends Component {
    constructor(props) {
        super(props);
        this.state = {
            fromDateTimeFilter: "",
            toDateTimeFilter:"",
            token: JSON.parse(localStorage.getItem("token")),
            options: {
                style: {
                    colors: ["#F44336", "#E91E63", "#9C27B0"],
                    fontSize: "12px",
                },
                chart: {
                    type: "bar",
                    height: "100%",
                    stacked: true,
                    stackType: "50%"
                },

                plotOptions: {
                    bar: {
                        horizontal: true,
                        distributed: true,
                        dataLabels: {
                            position: "insideTopRight",

                        },
                    }
                },
                dataLabels: {
                    textAnchor: "start",
                    enabled: true,
                    offsetX: 0,
                    style: {
                        fontSize: "12px",
                        colors: ["#000000"]
                    }
                },
                fill: {
                    colors: ["#feb139", "#4EBAE1"],
                    gradient: {
                        shade: "dark",
                        type: "horizontal",
                        shadeIntensity: 0.5,
                        gradientToColors: undefined,
                        inverseColors: true,
                        opacityFrom: 1,
                        opacityTo: 1,
                        stops: [0, 50, 100],
                        colorStops: []
                    },
                },

                xaxis: {
                    categories: this.props.lable,
                },
                grid: {
                    xaxis: {
                        tick: false,
                        lines: {
                            show: false
                        }
                    },

                    yaxis: {
                        min: 0,
                        max: 55,
                        tick: false,

                        lines: {
                            show: false
                        }
                    }
                },
                yaxis: {
                    reversed: true,
                    axisTicks: {
                        show: false
                    }
                },
                tooltip: {
                    enabled: false,
                    enabledOnSeries: undefined,
                    shared: true,
                    followCursor: false,
                    intersect: false,
                    inverseOrder: false,
                    custom: undefined,
                    fillSeriesColor: false,
                    theme: false,
                    style: {
                        fontSize: "12px",
                        fontFamily: undefined
                    },
                    onDatasetHover: {
                        highlightDataSeries: false,
                    },
                    x: {
                        show: true,
                        format: "dd MMM",
                        formatter: undefined,
                    },
                    y: {
                        formatter: undefined,
                        title: {
                            formatter: (seriesName) => seriesName,
                        },
                    },
                    z: {
                        formatter: undefined,
                        title: "Size: "
                    },
                    marker: {
                        show: false,
                    },
                    fixed: {
                        enabled: false,
                        position: "topRight",
                        offsetX: 0,
                        offsetY: 0,
                    },
                }

            },


        };
    }




    render() {
        console.log("sasasasas",this.props);
        return (
            <div className="col-xxl-12 col-md-12">
                <div className="card mb-4 chartbar4">
                    <div className="pb-0 card-header bg-transparent border-0">
                        <h4 className="mb-0 mt-2 text-center">Most Used Guides</h4>
                    </div>

                    <div className="card-body py-0">
                        <div className="position-relative">
                            <ReactApexChart
                                options={this.state.options}
                                series={[{
                                    data: this.props.series,
                                }]}
                                type="bar"
                                height={450}
                            />
                            {/* <div className="position-absolute">
                                <div className="mb-0 mb-2 h4 mt-0">"Some Random</div>
                                <div className="mb-0 mb-2 h4 mt-0">Quote</div>
                                <div className="mb-0 mb-2 h4 mt-0">About Compass</div>
                                <div className="mb-0 mb-3 h4 mt-0">or upcoming feature about</div>
                                <h4 className="mb-0 mb-2 h3 mt-0"> Compass "</h4>
                            </div> */}
                        </div>
                    </div>
                </div>
            </div>
        );
    }
}
